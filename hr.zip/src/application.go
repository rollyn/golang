package main

import (
	"fmt"
	"github.com/gin-gonic/gin"
)

var (
	config Config
	r = gin.Default()
)

func GoSCARFApplication() {
	c := config.getConf()
	Router()
	_ = r.Run(fmt.Sprintf(":%s",c.App.Port))
}
