package main


func main() {
	GoSCARFApplication()
}





