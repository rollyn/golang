package main

import (
	"github.com/gin-gonic/gin"
	"net/http"
)

var (
	invalidEmails []string
	inviteSent bool = false
	token Response
)

func GetIndexUI(c *gin.Context) {
	c.HTML(http.StatusOK, "index.html", nil)
}

func GetInvitationUI(c *gin.Context) {
	appConfig := config.getConf()
	exams := GetExams(appConfig)
	c.HTML(http.StatusOK, "invitation.html", gin.H{"exams":exams,
		"invalidEmails":invalidEmails,
		"inviteSent":inviteSent})
	inviteSent=false
}

func PageNotFoundController(c *gin.Context) {
	token = Response{}
	c.Redirect(http.StatusFound, invitation)
	c.Abort()
}

func LogoutController(c *gin.Context) {
	token = Response{}
	c.Redirect(http.StatusFound, invitation)
	c.Abort()
}

func LoginController(c *gin.Context) {
	username := c.PostForm("username")
	password := c.PostForm("password")
	if response := Login(username, password); response.Token != "" {
		token = Response{
			Username: username,
			Token: response.Token,
		}
		c.Redirect(http.StatusFound, invitation)
		c.Abort()
	} else {
		c.Redirect(http.StatusFound, home)
		c.Abort()
	}
}

func GetExamsController(c *gin.Context) {
	appConfig := config.getConf()
	exams := GetExams(appConfig)
	c.JSON(http.StatusOK, exams)
}

func PostInvitationController(c *gin.Context) {
	appConfig := config.getConf()
	examId := c.PostForm("exam")
	emails := c.PostForm("emails")
	invalidEmails = SendInvitation(appConfig, examId, emails)
	inviteSent = true
	c.Redirect(http.StatusFound, invitation)
	c.Abort()
}

