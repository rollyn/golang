package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"strings"
)

func SendInvitation(c *Config, examId string, emails string) []string {
	//proxy, err := url.Parse(c.Hr.Proxy.Uri)
	//if err != nil {
	//	panic(err)
	//}
	//client := &http.Client{Transport: &http.Transport{Proxy: http.ProxyURL(proxy)}}
	client := &http.Client{}
	invitees := strings.Split(emails, ",")

	var invalidEmails []string
	for _,invitee := range invitees {

		e := strings.ToLower(strings.TrimSpace(invitee))
		if IsValidEmail(e) {

			requestBody := &RequestBody{
				Id: examId,
				Email: e,
			}
			buf := new(bytes.Buffer)
			err := json.NewEncoder(buf).Encode(requestBody)
			if err != nil {
				log.Printf("unable to parse requestbody  #%v ", err)
			}
			uri := fmt.Sprintf("%s/%s/candidates",c.Hr.Uri, examId)
			request, err := http.NewRequest("POST", uri, buf)
			request.Header.Add("Authorization",c.Hr.Token)
			request.Header.Add("cache-control","no-cache")
			request.Header.Add("Content-Type","application/json")
			resp, err := client.Do(request)
			body, err := ioutil.ReadAll(resp.Body)
			if err != nil {
				log.Fatalf("unable to query hackerrank: %v", err)
			}
			log.Printf("invitation sent: examId: %s email: %s",examId,e)
			log.Printf("response: %s",body)
		} else {
			invalidEmails = append(invalidEmails, invitee)
		}
	}
	return invalidEmails;
}
