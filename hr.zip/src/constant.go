package main

const (
	invitation = "/invitation"
	home = "/"
	AlgoPBEWithMD5AndDES = "PBEWithMD5AndDES"
)
