package main

import (
	"github.com/gin-gonic/gin"
	"net/http"
)

func AuthTokenMiddleware(c *gin.Context) {
	if token.Token != "" {
		c.Next()
	} else {
		c.Redirect(http.StatusFound, home)
		c.Abort()
	}
}
