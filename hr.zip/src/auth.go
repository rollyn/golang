package main

import (
	"encoding/base64"
	"log"
	"astuart.co/go-jasypt"
)

func Login(username string, password string) *Response {
	response := &Response{}

	c := config.getConf()
	u := Decode(c.Credential.Username)
	p := Decode(c.Credential.Password)
	if u == username && p == password {
		response.Username = username
		response.Token = UuId()
	}
	return response
}

func Decode(input string) string {
	bs, err := base64.StdEncoding.DecodeString( input )
	if err != nil {
		log.Fatalf("unable to decode string %s",bs)
	}
	d := jasypt.Decryptor{
		Algorithm: AlgoPBEWithMD5AndDES,
		Password:  "SCARF",
	}
	out, err := d.Decrypt(bs)
	return string(out);
}