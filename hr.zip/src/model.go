package main

type Response struct {
	Token string
	Username string
}

type Config struct {
	Hr struct {
		Uri string
		Token string
		Proxy struct {
			Uri string
		}
	}
	App struct {
		Port string
	}
	Credential struct {
		Username string
		Password string
	}
}

type Exam struct {
	Id string
	Name string
	Locked bool
	Draft bool
}

type RequestBody struct {
	Id string `json:"id"`
	Email string `json:"email"`
}

