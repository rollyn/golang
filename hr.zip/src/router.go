package main

import (
	"github.com/gin-gonic/contrib/static"
)
func Router() {
	r.LoadHTMLGlob("templates/*.html")
	r.Use(static.Serve("/", static.LocalFile("templates", false)))
	r.GET("/", GetIndexUI)
	r.GET("/invitation",AuthTokenMiddleware,GetInvitationUI);
	r.NoRoute(PageNotFoundController)
	r.StaticFile("templates/slim_notifier.js", "./templates/slim_notifier.js")

	api := r.Group("/api")
	api.POST("/login", LoginController)

	api.Use(AuthTokenMiddleware)
	{
		api.GET("/exams", GetExamsController)
		api.POST("/invites", PostInvitationController)
		api.GET("/logout", LogoutController)
	}


}

