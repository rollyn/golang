package main

import "strings"

func Split(emails string) []string {
	return strings.Split(emails, ",")
}
