package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
)

func GetExams(c *Config) []Exam {
	//proxy, err := url.Parse(c.Hr.Proxy.Uri)
	//if err != nil {
	//	panic(err)
	//}
	//client := &http.Client{Transport: &http.Transport{Proxy: http.ProxyURL(proxy)}}
	client := &http.Client{}
	uri := fmt.Sprintf("%s%s",c.Hr.Uri, "?limit=10&offset=0")
	request, err := http.NewRequest("GET", uri, nil)
	request.Header.Add("Authorization",c.Hr.Token)
	request.Header.Add("cache-control","no-cache")
	resp, err := client.Do(request)
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("unable to query hackerrank: %v", err)
	}
	respBody := marshal(body)
	var exams []Exam
	for _,v := range respBody {
		if v.Draft == false {
			exams = append(exams, v)
		}
	}
	return exams
}

func marshal(body []byte) []Exam {
	var result  map[string]interface{}
	err := json.Unmarshal(body, &result)
	if err != nil {
		log.Fatal(err)
	}
	data, _ := json.Marshal(result["data"])
	if err != nil {
		log.Fatal(err)
	}
	var res []Exam
	err = json.Unmarshal([]byte(data), &res)
	if err != nil {
		log.Fatal(err)
	}
	return res;
}
