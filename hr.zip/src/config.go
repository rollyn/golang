package main

import (
	"gopkg.in/yaml.v2"
	"io/ioutil"
	"log"
)

func (c *Config) getConf() *Config {

	yamlFile, err := ioutil.ReadFile("application.yml")
	if err != nil {
		log.Printf("unable to load application.yml  #%v ", err)
	}
	err = yaml.Unmarshal(yamlFile, c)
	if err != nil {
		log.Fatalf("unable to marshal config: %v", err)
	}
	return c
}

